/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mychatapp;

import java.util.Scanner;

/**
 *
 * @author Phetogo Komane
 */
public class MyChatApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
 







    /**
     * @param args the command line arguments
     */
    
        Scanner input = new Scanner(System.in);
        Login objLogin = new Login();
        
        System.out.println("=== MYCHATAPP REGISTRATION ===\n");
        //collect name and surname - readline()
        System.out.print("Enter your name: ");
        String name = input.nextLine();
        
        System.out.print("Enter your surname: ");
        String surname = input.nextLine();
        
        System.out.print("Create a username (max 5 chars, must contain _ ): ");
        String username = input.nextLine();
        
        System.out.print("Create a password (8+ chars, uppercase, number, special): ");
        String password = input.nextLine();
        
        System.out.print("Enter cell number (+27 followed by 9 digits): ");
        String phone = input.nextLine();
        
        System.out.println("\n" + objLogin.registerUser(username, password, phone));
        
        System.out.println("\n=== LOGIN ===\n");
        System.out.print("Enter username: ");
        String loginUser = input.nextLine();
        
        System.out.print("Enter password: ");
        String loginPass = input.nextLine();
        
        System.out.println(objLogin.returnLoginStatus(loginUser, loginPass, username, password));
        
        if (objLogin.loginUser(loginUser, loginPass, username, password)) {
            System.out.println("Welcome back " + name + " " + surname + "!");
        }
        
        input.close();
    }
}       // TODO code application logic here