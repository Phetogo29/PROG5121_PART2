/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mychatapp;

/**
 *
 * @author Phetogo Komane
 */
class Login {
  


   //checks if the username meets the required format :
    public boolean checkUserName(String username) {
        return username.length() <= 5 && username.contains("_");
    }
    //checks if the passwords meets cmplexity requirements :
    public boolean checkPasswordComplexity(String password) {
        boolean hasLength = password.length() >= 8;
        boolean hasUppercase = password.matches(".*[A-Z].*");
        boolean hasNumbers = password.matches(".*[0-9].*");
        boolean hasSpecial = !password.matches("[A-Za-z0-9]*");
        
        return hasLength && hasUppercase && hasNumbers && hasSpecial;
    }
    //checks if the cellphone number is valid :
    public boolean checkCellPhoneNumber(String number) {
        return number.length() == 12 && number.startsWith("+27");
    }
    
    public String registerUser(String username, String password, String phone) {
        if (!checkUserName(username)) {
            return "Username invalid: must be 5 chars or less and contain _";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password invalid: 8+ chars, uppercase, number, special char";
        }
        if (!checkCellPhoneNumber(phone)) {
            return "Phone invalid: +27 followed by 9 digits";
        }
        return "Registration successful!";
    }
    //checks if the entered login credentials match the registration credentials.
    public boolean loginUser(String enteredUsername, String enteredPassword, String storedUsername, String storedPassword) {
        return enteredUsername.equals(storedUsername) && enteredPassword.equals(storedPassword);
    }
    
    public String returnLoginStatus(String enteredUsername, String enteredPassword, String storedUsername, String storedPassword) {
        if (loginUser(enteredUsername, enteredPassword, storedUsername, storedPassword)) {
            return "Login successful! Welcome!";
        } else {
            return "Login failed: Incorrect username or password";
        }
    }
}
